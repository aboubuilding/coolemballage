<!-- <div class="section margin-top_50"> -->
    <!-- <section id="counter_threeup" class="counter_threeup lightbg sections">
        <div class="container">
            <div class="row">
                <div class="counter_threeup-wrapper">
                    <div class="col-md-3 col-sm-6 col-xs-12">
                        <div class="counter_threeup">
                            <div class="counter_threeup-photo">
                                <img src="http://i.imgur.com/7jmZxc8.png" alt="counter_threeup" />
                            </div>
                            <div class="counter_threeup-content">
                                <h5 class="count-number">11</h5>
                                <h6>Designers</h6>
                            </div>
                        </div>
                    </div>

                    <div class="col-md-3 col-sm-6 col-xs-12">
                        <div class="counter_threeup">
                            <div class="counter_threeup-photo">
                                <img src="http://i.imgur.com/s3fDOCZ.png" alt="counter_threeup" />
                            </div>
                            <div class="counter_threeup-content">
                                <h5 class="count-number">6542</h5>
                                <h6>Hours Worked</h6>
                            </div>
                        </div>
                    </div>

                    <div class="col-md-3 col-sm-6 col-xs-12">
                        <div class="counter_threeup">
                            <div class="counter_threeup-photo">
                                <img src="http://i.imgur.com/UYLWCDw.png" alt="counter_threeup" />
                            </div>
                            <div class="counter_threeup-content">
                                <h5 class="count-number">254</h5>
                                <h6>Project finished</h6>
                            </div>
                        </div>
                    </div>

                    <div class="col-md-3 col-sm-6 col-xs-12">
                        <div class="counter_threeup">
                            <div class="counter_threeup-photo">
                                <img src="http://i.imgur.com/IVfjEcU.png" alt="counter_threeup" />
                            </div>
                            <div class="counter_threeup-content">
                                <h5 class="count-number">435</h5>
                                <h6>Drunk coffee</h6>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </section> -->

<!-- </div> -->